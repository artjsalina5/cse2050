import unittest, random
from MyBSTMap import MyBSTMap

class TestMyBSTMap(unittest.TestCase):
    def test_equal_empty(self):
        """ADD DOCSTRING"""

    def test_equal_multiplenodes(self):
        """ADD DOCSTRING"""

    def test_notequal_multiplenodes_difshapes(self):
        """ADD DOCSTRING"""
    
    def test_notequal_multiplenodes_difkvs(self):
        """ADD DOCSTRING"""

    def test_frompreorder_small(self):
        """ADD DOCSTRING"""

    def test_frompreorder_large(self):
        """ADD DOCSTRING"""

    def test_frompostorder_small(self):
        """ADD DOCSTRING"""

    def test_frompostorder_large(self):
        """ADD DOCSTRING"""

unittest.main()