from BSTMap import BSTMap, BSTNode # provided for you

# Inherit from BSTMap, but overload `newnode` to use this one instead
class MyBSTMap(BSTMap):
    
    def newnode(self, key, value = None): 
        return MyBSTNode(key, value)    # overloads the `newnode` method to use MyBSTNode() instead of BSTNode()

    # TODO: implement the three methods below
    def __eq__(self, other):
        """ADD DOCSTRING"""
             # The heavy lifting here is done in the corresponding
             # function in MyBSTNode - just tell it which node to
             # start with.
        L1 = [(k, v) for (k, v) in self.preorder()]
        L2 = [(k, v) for (k, v) in self.preorder()]
        return (L1 == L2)


     # these are "static" methods - they belong to the class but do not take an instance of
    # the class as a parameter (no `self``).
    # note the "decorator" @staticmethod - this let's python know this is not a typical "bound" method
    @staticmethod
    def frompreorder(L):
        """ADD DOCSTRING"""
        new_bst = MyBSTMap()
        for key_value in L:
            new_bst.put(key_value[0], key_value[1])
        return new_bst

    @staticmethod
    def frompostorder(L):
        """ADD DOCSTRING"""

class MyBSTNode(BSTNode):
    
    newnode = MyBSTMap.newnode  # overloads the `newnode` method to use the correct Node class

    # TODO: implement the method below
    def __eq__(self, other):
        """ADD DOCSTRING"""
